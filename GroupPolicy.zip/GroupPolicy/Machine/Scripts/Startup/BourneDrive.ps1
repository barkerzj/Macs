Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "EnableLinkedConnections" -Value 00000001
Get-PSDrive Z | Remove-PSDrive -Force
$User = $Env:UserName
$PWord = ConvertTo-SecureString -String "bumpyJ@ckal24" -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $User, $PWord
New-PSDrive -Name "Z" -PSProvider "FileSystem" -Root "\\bourne-srv\Bourne" -Credential $Credential -Persist
echo "THis Ran" >c:\temp\$Env:UserName.txt