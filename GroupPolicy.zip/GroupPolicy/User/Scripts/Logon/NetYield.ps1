$ipAddress = (Get-NetIPConfiguration | Where-Object {$_.IPv4DefaultGateway -ne $null -and $_.NetAdapter.status -ne "Disconnected"}).IPv4Address.IPAddress

if ($ipAddress -like '192.168.1.*') #Bourne
 {
$net = new-object -ComObject WScript.Network
$net.MapNetworkDrive("N:", "\\192.168.1.6\netyield", $true, "itnetyield", "N3tYi3ld")
 }
elseif ($ipAddress -like '192.168.3.*') #Steuben
 {
$net = new-object -ComObject WScript.Network
$net.MapNetworkDrive("N:", "\\192.168.3.5\netyield", $true, "itnetyield", "N3tYi3ld")
 }
elseif ($ipAddress -like '192.168.9.*') #Machiasport
 {
$net = new-object -ComObject WScript.Network
$net.MapNetworkDrive("N:", "\\192.168.9.5\netyield", $true, "itnetyield", "N3tYi3ld")
}
